﻿=== Super Mario Bros. (SNES) Big Mario Cursor Set ===

By: Virum64 (http://www.rw-designer.com/user/30267) virum64@gmail.com

Download: http://www.rw-designer.com/cursor-set/smb-snes-mario

Author's description:

I wanted to make a Mario cursor set and I had to choose between Super Mario Bros. (NES) and Super Mario World (SNES). So I decided to make a cursor set about Super Mario Bros. from Super Mario All Stars on SNES.
Sprites ripped by Techokami.
Here is Big Mario version.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.